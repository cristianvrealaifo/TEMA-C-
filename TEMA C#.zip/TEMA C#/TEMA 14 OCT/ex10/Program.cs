﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string sir = "Acesta este un sir";
            char[] delimitator = { ' ', ',', '.', ':' };
            Console.WriteLine("Sirul care fi impartit in cuvinte\n'{0}',", sir);
            string[] cuvant = sir.Split(delimitator);
            Console.WriteLine("sunt {0} cuvinte in text:", cuvant.Length);
            foreach (string s in cuvant)
            {
                Console.WriteLine(s); 
                Console.ReadKey();
            }
        }
    }
}
