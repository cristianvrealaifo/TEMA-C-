﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EX_CU_ZILELE_SAPT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int zi;
            Console.WriteLine("Dati ziua");
            try
            {
                zi = int.Parse(Console.ReadLine());
                switch (zi)
                {
                    case 1: Console.WriteLine("Luni"); break;
                    case 2: Console.WriteLine("Marti"); break;
                    case 3: Console.WriteLine("miercuri");break;
                    case 4: Console.WriteLine("jOI"); break;
                    case 5: Console.WriteLine("Viner"); break;
                    case 6: Console.WriteLine("sambata"); break;
                    case 7: Console.WriteLine("duminica"); break;
                    default: Console.WriteLine("zi eronata;"); break;
                }
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
