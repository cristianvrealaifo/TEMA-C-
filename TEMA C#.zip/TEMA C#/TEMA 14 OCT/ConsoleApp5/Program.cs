﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("alegeti una dintre variantele 1, 2 sau 3");
            do
            {
                Console.WriteLine("varianta=");
                n = int.Parse(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        Console.WriteLine("Ati ales varianta 1");
                        goto case 4;
                    case 2:
                        Console.WriteLine("Ati ales varianta 2");
                        break;
                    case 3:
                        Console.WriteLine("Ati ales varianta 3");
                        break;
                    case 4:
                        Console.WriteLine("Sunteti norocosi beneficiati si de varianta 4");
                        break;
                }
            } while (n != 1 && n != 2 && n != 3);
            Console.ReadLine();

                }
            }

        }
    

