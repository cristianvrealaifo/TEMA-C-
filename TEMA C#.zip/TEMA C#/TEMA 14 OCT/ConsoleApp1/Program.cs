﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            while (n <= 10)
            {
                Console.Write("{0,3}", n);
                n++;
            }
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
