﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_2__distanta_maxima_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double g = 9.81, d = 0, dd;
            int t = 0;
            Console.WriteLine("Dati distanta maxima");
            try
            {
                dd = int.Parse(Console.ReadLine());
                while (d <= dd)
                {
                    d = (g * t * t) / 2;
                    Console.WriteLine(t.ToString() + " " + d);
                    t += 1;
                }
                t = 0;
                do
                {
                    d = (g * t * t) / 2;
                    Console.WriteLine(t.ToString() + " " + d);
                    t += 1;

                } while (d <= dd);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            Console.ReadLine();
                }
            }
        }
    

